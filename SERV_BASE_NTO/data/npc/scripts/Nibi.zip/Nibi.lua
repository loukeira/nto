local keywordHandler = KeywordHandler:new()
local npcHandler = NpcHandler:new(keywordHandler)
NpcSystem.parseParameters(npcHandler)
local talkState = {}
function onCreatureAppear(cid) npcHandler:onCreatureAppear(cid) end
function onCreatureDisappear(cid) npcHandler:onCreatureDisappear(cid) end
function onCreatureSay(cid, type, msg) npcHandler:onCreatureSay(cid, type, msg) end
function onThink() npcHandler:onThink() end
function creatureSayCallback(cid, type, msg)
if(not npcHandler:isFocused(cid)) then
return false
end
local talkUser = NPCHANDLER_CONVbehavior == CONVERSATION_DEFAULT and 0 or cid
local msg,stor = string.lower(msg),754487
local elements = {
["transforma�ao"] = {"bijuu furie"},
["attack"] = {"katon bijuu rasengan"}
}
if elements[msg] then
if getPlayerStorageValue(cid, stor) <= 0 then
for _, spells in ipairs(elements[msg]) do
doPlayerLearnInstantSpell(cid, spells)
end
setPlayerStorageValue(cid,stor,1)
npcHandler:say("Parab�ns, voce aprendeu meu jutsu "..msg, cid)
else
npcHandler:say("voce ja pegou meu attack.", cid)
end
else
npcHandler:say("este attack n�o existe.", cid)
end
return true
end
npcHandler:setCallback(CALLBACK_MESSAGE_DEFAULT, creatureSayCallback)
npcHandler:addModule(FocusModule:new())